//
//  MessageTableViewCellDTO.swift
//  marvelapp
//
//  Created by Felipe Antonio Cardoso on 07/04/19.
//  Copyright © 2019 Felipe Antonio Cardoso. All rights reserved.
//

import Foundation

struct MessageTableViewCellDTO {
    let title: String
}
