//
//  LaunchArguments.swift
//  marvelapp
//
//  Created by Felipe Antonio Cardoso on 14/04/19.
//  Copyright © 2019 Felipe Antonio Cardoso. All rights reserved.
//

import Foundation

enum LaunchArguments: String {
    case mockNetworkResponses
}
